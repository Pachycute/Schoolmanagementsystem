﻿Public Class Receipt

End Class