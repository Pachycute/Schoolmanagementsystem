﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ENROLLMENT_STUDENT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ENROLLMENT_STUDENT))
        Panel1 = New Panel()
        RadioButtonafternoon = New RadioButton()
        RadioButtonmorning = New RadioButton()
        Label29 = New Label()
        TableLayoutPanel3 = New TableLayoutPanel()
        Label49 = New Label()
        Label34 = New Label()
        Label38 = New Label()
        Label42 = New Label()
        Label22 = New Label()
        Label21 = New Label()
        Label20 = New Label()
        Label19 = New Label()
        Label23 = New Label()
        Label24 = New Label()
        Label25 = New Label()
        Label26 = New Label()
        Label27 = New Label()
        Label28 = New Label()
        Label33 = New Label()
        Label36 = New Label()
        Label35 = New Label()
        Label43 = New Label()
        Label44 = New Label()
        Label46 = New Label()
        Label47 = New Label()
        Label48 = New Label()
        Label50 = New Label()
        Label53 = New Label()
        Label52 = New Label()
        Label51 = New Label()
        Label45 = New Label()
        Label30 = New Label()
        Label40 = New Label()
        Panel2 = New Panel()
        TableLayoutPanel2 = New TableLayoutPanel()
        Label18 = New Label()
        Label17 = New Label()
        Label16 = New Label()
        Label15 = New Label()
        CheckBoxhumms = New CheckBox()
        CheckBoxabm = New CheckBox()
        CheckBoxict = New CheckBox()
        CheckBoxhe = New CheckBox()
        Label10 = New Label()
        TableLayoutPanel1 = New TableLayoutPanel()
        txtlrn = New TextBox()
        txtname = New TextBox()
        CheckBox2nd = New CheckBox()
        CheckBox1st = New CheckBox()
        Label11 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        Label14 = New Label()
        cmbstatus = New ComboBox()
        Label9 = New Label()
        cmbsection = New ComboBox()
        Label8 = New Label()
        Label7 = New Label()
        txtregnum = New TextBox()
        Label6 = New Label()
        cmbtrack = New ComboBox()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        Button5 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        PictureBox2 = New PictureBox()
        Button1 = New Button()
        Panel1.SuspendLayout()
        TableLayoutPanel3.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        TableLayoutPanel1.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.ActiveBorder
        Panel1.Controls.Add(RadioButtonafternoon)
        Panel1.Controls.Add(RadioButtonmorning)
        Panel1.Controls.Add(Label29)
        Panel1.Controls.Add(TableLayoutPanel3)
        Panel1.Controls.Add(Panel2)
        Panel1.Controls.Add(TableLayoutPanel2)
        Panel1.Controls.Add(Label10)
        Panel1.Controls.Add(TableLayoutPanel1)
        Panel1.Controls.Add(cmbstatus)
        Panel1.Controls.Add(Label9)
        Panel1.Controls.Add(cmbsection)
        Panel1.Controls.Add(Label8)
        Panel1.Controls.Add(Label7)
        Panel1.Controls.Add(txtregnum)
        Panel1.Controls.Add(Label6)
        Panel1.Controls.Add(cmbtrack)
        Panel1.Controls.Add(Label5)
        Panel1.Controls.Add(Label4)
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(Label2)
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(2, 25)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(826, 539)
        Panel1.TabIndex = 0
        ' 
        ' RadioButtonafternoon
        ' 
        RadioButtonafternoon.AutoSize = True
        RadioButtonafternoon.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        RadioButtonafternoon.Location = New Point(718, 146)
        RadioButtonafternoon.Name = "RadioButtonafternoon"
        RadioButtonafternoon.Size = New Size(89, 21)
        RadioButtonafternoon.TabIndex = 21
        RadioButtonafternoon.TabStop = True
        RadioButtonafternoon.Text = "Afternoon"
        RadioButtonafternoon.UseVisualStyleBackColor = True
        ' 
        ' RadioButtonmorning
        ' 
        RadioButtonmorning.AutoSize = True
        RadioButtonmorning.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        RadioButtonmorning.Location = New Point(607, 147)
        RadioButtonmorning.Name = "RadioButtonmorning"
        RadioButtonmorning.Size = New Size(79, 21)
        RadioButtonmorning.TabIndex = 20
        RadioButtonmorning.TabStop = True
        RadioButtonmorning.Text = "Morning"
        RadioButtonmorning.UseVisualStyleBackColor = True
        ' 
        ' Label29
        ' 
        Label29.AutoSize = True
        Label29.BackColor = SystemColors.ActiveBorder
        Label29.BorderStyle = BorderStyle.Fixed3D
        Label29.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label29.Location = New Point(462, 152)
        Label29.Name = "Label29"
        Label29.Size = New Size(66, 19)
        Label29.TabIndex = 19
        Label29.Text = "Semester"
        Label29.TextAlign = ContentAlignment.BottomCenter
        ' 
        ' TableLayoutPanel3
        ' 
        TableLayoutPanel3.CellBorderStyle = TableLayoutPanelCellBorderStyle.Outset
        TableLayoutPanel3.ColumnCount = 6
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 19.1397858F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 80.8602142F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 41F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 87F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 87F))
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 210F))
        TableLayoutPanel3.Controls.Add(Label49, 4, 0)
        TableLayoutPanel3.Controls.Add(Label34, 1, 1)
        TableLayoutPanel3.Controls.Add(Label38, 1, 2)
        TableLayoutPanel3.Controls.Add(Label42, 1, 3)
        TableLayoutPanel3.Controls.Add(Label22, 3, 0)
        TableLayoutPanel3.Controls.Add(Label21, 2, 0)
        TableLayoutPanel3.Controls.Add(Label20, 1, 0)
        TableLayoutPanel3.Controls.Add(Label19, 0, 0)
        TableLayoutPanel3.Controls.Add(Label23, 0, 1)
        TableLayoutPanel3.Controls.Add(Label24, 0, 2)
        TableLayoutPanel3.Controls.Add(Label25, 0, 3)
        TableLayoutPanel3.Controls.Add(Label26, 0, 4)
        TableLayoutPanel3.Controls.Add(Label27, 0, 5)
        TableLayoutPanel3.Controls.Add(Label28, 0, 6)
        TableLayoutPanel3.Controls.Add(Label33, 1, 4)
        TableLayoutPanel3.Controls.Add(Label36, 1, 5)
        TableLayoutPanel3.Controls.Add(Label35, 1, 6)
        TableLayoutPanel3.Controls.Add(Label43, 3, 1)
        TableLayoutPanel3.Controls.Add(Label44, 3, 2)
        TableLayoutPanel3.Controls.Add(Label46, 3, 4)
        TableLayoutPanel3.Controls.Add(Label47, 3, 5)
        TableLayoutPanel3.Controls.Add(Label48, 3, 3)
        TableLayoutPanel3.Controls.Add(Label50, 4, 1)
        TableLayoutPanel3.Controls.Add(Label53, 5, 1)
        TableLayoutPanel3.Controls.Add(Label52, 5, 2)
        TableLayoutPanel3.Controls.Add(Label51, 5, 3)
        TableLayoutPanel3.Controls.Add(Label45, 5, 4)
        TableLayoutPanel3.Controls.Add(Label30, 0, 7)
        TableLayoutPanel3.Controls.Add(Label40, 1, 7)
        TableLayoutPanel3.Location = New Point(0, 229)
        TableLayoutPanel3.Name = "TableLayoutPanel3"
        TableLayoutPanel3.RowCount = 11
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 57.5757561F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 42.4242439F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Absolute, 26F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Absolute, 24F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Absolute, 24F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Absolute, 25F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Absolute, 26F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Absolute, 26F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Absolute, 23F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Absolute, 26F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Absolute, 21F))
        TableLayoutPanel3.Size = New Size(823, 310)
        TableLayoutPanel3.TabIndex = 18
        ' 
        ' Label49
        ' 
        Label49.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label49.Location = New Point(524, 2)
        Label49.Name = "Label49"
        Label49.Size = New Size(80, 37)
        Label49.TabIndex = 50
        Label49.Text = "TUITION"
        Label49.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label34
        ' 
        Label34.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label34.Location = New Point(80, 41)
        Label34.Name = "Label34"
        Label34.Size = New Size(304, 26)
        Label34.TabIndex = 35
        Label34.Text = "ORAL COMMUNICATION"
        Label34.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label38
        ' 
        Label38.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label38.Location = New Point(80, 70)
        Label38.Name = "Label38"
        Label38.Size = New Size(304, 26)
        Label38.TabIndex = 39
        Label38.Text = "KOMUNIKASYON AT PANALASIKSIK SA WIKA NG KULTURANG PILIPINO"
        Label38.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label42
        ' 
        Label42.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label42.Location = New Point(80, 98)
        Label42.Name = "Label42"
        Label42.Size = New Size(304, 24)
        Label42.TabIndex = 43
        Label42.Text = "GENERAL MATHEMATICS "
        Label42.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label22
        ' 
        Label22.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label22.Location = New Point(435, 2)
        Label22.Name = "Label22"
        Label22.Size = New Size(80, 37)
        Label22.TabIndex = 23
        Label22.Text = "FREEBIES"
        Label22.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label21
        ' 
        Label21.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label21.Location = New Point(392, 2)
        Label21.Name = "Label21"
        Label21.Size = New Size(35, 37)
        Label21.TabIndex = 22
        Label21.Text = "UNITS"
        Label21.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label20
        ' 
        Label20.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label20.Location = New Point(80, 2)
        Label20.Name = "Label20"
        Label20.Size = New Size(304, 37)
        Label20.TabIndex = 21
        Label20.Text = "Subject Description"
        Label20.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label19
        ' 
        Label19.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label19.Location = New Point(5, 2)
        Label19.Name = "Label19"
        Label19.Size = New Size(67, 37)
        Label19.TabIndex = 20
        Label19.Text = "Subject Code"
        Label19.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label23
        ' 
        Label23.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label23.Location = New Point(5, 41)
        Label23.Name = "Label23"
        Label23.Size = New Size(67, 27)
        Label23.TabIndex = 24
        Label23.Text = "ENG111"
        Label23.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label24
        ' 
        Label24.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label24.Location = New Point(5, 70)
        Label24.Name = "Label24"
        Label24.Size = New Size(67, 26)
        Label24.TabIndex = 25
        Label24.Text = "FIL111"
        Label24.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label25
        ' 
        Label25.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label25.Location = New Point(5, 98)
        Label25.Name = "Label25"
        Label25.Size = New Size(67, 24)
        Label25.TabIndex = 26
        Label25.Text = "MTH111"
        Label25.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label26
        ' 
        Label26.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label26.Location = New Point(5, 124)
        Label26.Name = "Label26"
        Label26.Size = New Size(67, 24)
        Label26.TabIndex = 27
        Label26.Text = "SCI111"
        Label26.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label27
        ' 
        Label27.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label27.Location = New Point(5, 150)
        Label27.Name = "Label27"
        Label27.Size = New Size(67, 25)
        Label27.TabIndex = 28
        Label27.Text = "LIT"
        Label27.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label28
        ' 
        Label28.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label28.Location = New Point(5, 177)
        Label28.Name = "Label28"
        Label28.Size = New Size(67, 26)
        Label28.TabIndex = 29
        Label28.Text = "PE1"
        Label28.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label33
        ' 
        Label33.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label33.Location = New Point(80, 124)
        Label33.Name = "Label33"
        Label33.Size = New Size(304, 24)
        Label33.TabIndex = 34
        Label33.Text = " EARTH AND LIFE SCIENCE"
        Label33.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label36
        ' 
        Label36.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label36.Location = New Point(80, 150)
        Label36.Name = "Label36"
        Label36.Size = New Size(304, 25)
        Label36.TabIndex = 37
        Label36.Text = "21ST CENTURY LITERATURE FROM THE PHILIPPINES AND THE WORLD"
        Label36.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label35
        ' 
        Label35.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label35.Location = New Point(80, 177)
        Label35.Name = "Label35"
        Label35.Size = New Size(304, 26)
        Label35.TabIndex = 36
        Label35.Text = "PHYSICAL EDUCATION AND HEALTH"
        Label35.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label43
        ' 
        Label43.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label43.Location = New Point(435, 41)
        Label43.Name = "Label43"
        Label43.Size = New Size(80, 24)
        Label43.TabIndex = 44
        Label43.Text = "1 SET DAILY UNIFORM"
        Label43.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label44
        ' 
        Label44.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label44.Location = New Point(435, 70)
        Label44.Name = "Label44"
        Label44.Size = New Size(80, 24)
        Label44.TabIndex = 45
        Label44.Text = "1 SET P.E UNIFORM"
        Label44.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label46
        ' 
        Label46.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label46.Location = New Point(435, 124)
        Label46.Name = "Label46"
        Label46.Size = New Size(80, 24)
        Label46.TabIndex = 47
        Label46.Text = "ID AND LACE"
        Label46.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label47
        ' 
        Label47.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label47.Location = New Point(435, 150)
        Label47.Name = "Label47"
        Label47.Size = New Size(80, 24)
        Label47.TabIndex = 48
        Label47.Text = "ID AND LANYARD"
        Label47.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label48
        ' 
        Label48.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label48.Location = New Point(435, 98)
        Label48.Name = "Label48"
        Label48.Size = New Size(80, 24)
        Label48.TabIndex = 49
        Label48.Text = "1 SHS SHIRT"
        Label48.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label50
        ' 
        Label50.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label50.Location = New Point(524, 41)
        Label50.Name = "Label50"
        Label50.Size = New Size(80, 27)
        Label50.TabIndex = 51
        Label50.Text = "17,500.00"
        Label50.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label53
        ' 
        Label53.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label53.ForeColor = Color.Red
        Label53.Location = New Point(613, 41)
        Label53.Name = "Label53"
        Label53.Size = New Size(205, 27)
        Label53.TabIndex = 54
        Label53.Text = "FREE IF VOUCHER RECEPIENT"
        Label53.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label52
        ' 
        Label52.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label52.ForeColor = Color.Red
        Label52.Location = New Point(613, 70)
        Label52.Name = "Label52"
        Label52.Size = New Size(205, 26)
        Label52.TabIndex = 53
        Label52.Text = "FREE IF G10 PUBLIC COMPLETER"
        Label52.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label51
        ' 
        Label51.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label51.ForeColor = Color.Red
        Label51.Location = New Point(613, 98)
        Label51.Name = "Label51"
        Label51.Size = New Size(205, 24)
        Label51.TabIndex = 52
        Label51.Text = "TO APPLY VOUCHER"
        Label51.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label45
        ' 
        Label45.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label45.Location = New Point(613, 124)
        Label45.Name = "Label45"
        Label45.Size = New Size(205, 24)
        Label45.TabIndex = 55
        Label45.Text = "(payable for 1 year, Installment)"
        Label45.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label30
        ' 
        Label30.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label30.Location = New Point(5, 205)
        Label30.Name = "Label30"
        Label30.Size = New Size(67, 23)
        Label30.TabIndex = 31
        Label30.Text = "PDEV"
        Label30.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label40
        ' 
        Label40.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label40.Location = New Point(80, 205)
        Label40.Name = "Label40"
        Label40.Size = New Size(304, 23)
        Label40.TabIndex = 41
        Label40.Text = "PERSONALITY DEVELOPMENT"
        Label40.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = SystemColors.ControlDarkDark
        Panel2.Location = New Point(0, 216)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(826, 11)
        Panel2.TabIndex = 17
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.Outset
        TableLayoutPanel2.ColumnCount = 4
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 83.1932755F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 16.8067226F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 91F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 18F))
        TableLayoutPanel2.Controls.Add(Label18, 2, 1)
        TableLayoutPanel2.Controls.Add(Label17, 0, 1)
        TableLayoutPanel2.Controls.Add(Label16, 2, 0)
        TableLayoutPanel2.Controls.Add(Label15, 0, 0)
        TableLayoutPanel2.Controls.Add(CheckBoxhumms, 1, 1)
        TableLayoutPanel2.Controls.Add(CheckBoxabm, 1, 0)
        TableLayoutPanel2.Controls.Add(CheckBoxict, 3, 0)
        TableLayoutPanel2.Controls.Add(CheckBoxhe, 3, 1)
        TableLayoutPanel2.Location = New Point(591, 171)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 2
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel2.Size = New Size(235, 46)
        TableLayoutPanel2.TabIndex = 16
        ' 
        ' Label18
        ' 
        Label18.Font = New Font("Segoe UI Black", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label18.Location = New Point(124, 24)
        Label18.Name = "Label18"
        Label18.Size = New Size(82, 20)
        Label18.TabIndex = 26
        Label18.Text = "HE"
        Label18.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label17
        ' 
        Label17.Font = New Font("Segoe UI Black", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label17.Location = New Point(5, 24)
        Label17.Name = "Label17"
        Label17.Size = New Size(82, 20)
        Label17.TabIndex = 25
        Label17.Text = "HUMSS"
        Label17.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label16
        ' 
        Label16.Font = New Font("Segoe UI Black", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label16.Location = New Point(124, 2)
        Label16.Name = "Label16"
        Label16.Size = New Size(82, 20)
        Label16.TabIndex = 24
        Label16.Text = "ICT"
        Label16.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label15
        ' 
        Label15.Font = New Font("Segoe UI Black", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label15.Location = New Point(5, 2)
        Label15.Name = "Label15"
        Label15.Size = New Size(90, 20)
        Label15.TabIndex = 23
        Label15.Text = "ABM"
        Label15.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' CheckBoxhumms
        ' 
        CheckBoxhumms.Location = New Point(103, 27)
        CheckBoxhumms.Name = "CheckBoxhumms"
        CheckBoxhumms.Size = New Size(13, 14)
        CheckBoxhumms.TabIndex = 17
        CheckBoxhumms.Text = "HUMMS"
        CheckBoxhumms.UseVisualStyleBackColor = True
        ' 
        ' CheckBoxabm
        ' 
        CheckBoxabm.Location = New Point(103, 5)
        CheckBoxabm.Name = "CheckBoxabm"
        CheckBoxabm.Size = New Size(13, 14)
        CheckBoxabm.TabIndex = 17
        CheckBoxabm.Text = "ABM"
        CheckBoxabm.UseVisualStyleBackColor = True
        ' 
        ' CheckBoxict
        ' 
        CheckBoxict.Location = New Point(217, 5)
        CheckBoxict.Name = "CheckBoxict"
        CheckBoxict.Size = New Size(13, 14)
        CheckBoxict.TabIndex = 18
        CheckBoxict.Text = "ICT"
        CheckBoxict.UseVisualStyleBackColor = True
        ' 
        ' CheckBoxhe
        ' 
        CheckBoxhe.Location = New Point(217, 27)
        CheckBoxhe.Name = "CheckBoxhe"
        CheckBoxhe.Size = New Size(13, 14)
        CheckBoxhe.TabIndex = 19
        CheckBoxhe.Text = "HE"
        CheckBoxhe.UseVisualStyleBackColor = True
        ' 
        ' Label10
        ' 
        Label10.BackColor = SystemColors.ControlDarkDark
        Label10.BorderStyle = BorderStyle.Fixed3D
        Label10.Font = New Font("Elephant", 8.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(530, 171)
        Label10.Name = "Label10"
        Label10.Size = New Size(60, 44)
        Label10.TabIndex = 15
        Label10.Text = "Strands" & vbCrLf
        Label10.TextAlign = ContentAlignment.BottomCenter
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Outset
        TableLayoutPanel1.ColumnCount = 4
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 19.1397858F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 80.8602142F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 19F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 40F))
        TableLayoutPanel1.Controls.Add(txtlrn, 1, 1)
        TableLayoutPanel1.Controls.Add(txtname, 1, 0)
        TableLayoutPanel1.Controls.Add(CheckBox2nd, 2, 1)
        TableLayoutPanel1.Controls.Add(CheckBox1st, 2, 0)
        TableLayoutPanel1.Controls.Add(Label11, 0, 0)
        TableLayoutPanel1.Controls.Add(Label12, 0, 1)
        TableLayoutPanel1.Controls.Add(Label13, 3, 0)
        TableLayoutPanel1.Controls.Add(Label14, 3, 1)
        TableLayoutPanel1.Location = New Point(0, 170)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 2
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel1.Size = New Size(531, 46)
        TableLayoutPanel1.TabIndex = 14
        ' 
        ' txtlrn
        ' 
        txtlrn.BackColor = Color.Silver
        txtlrn.BorderStyle = BorderStyle.FixedSingle
        txtlrn.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txtlrn.Location = New Point(95, 27)
        txtlrn.Multiline = True
        txtlrn.Name = "txtlrn"
        txtlrn.Size = New Size(367, 14)
        txtlrn.TabIndex = 24
        ' 
        ' txtname
        ' 
        txtname.BackColor = Color.Silver
        txtname.BorderStyle = BorderStyle.FixedSingle
        txtname.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txtname.Location = New Point(95, 5)
        txtname.Multiline = True
        txtname.Name = "txtname"
        txtname.Size = New Size(367, 14)
        txtname.TabIndex = 23
        ' 
        ' CheckBox2nd
        ' 
        CheckBox2nd.Location = New Point(470, 27)
        CheckBox2nd.Name = "CheckBox2nd"
        CheckBox2nd.Size = New Size(13, 14)
        CheckBox2nd.TabIndex = 16
        CheckBox2nd.Text = "2nd"
        CheckBox2nd.UseVisualStyleBackColor = True
        ' 
        ' CheckBox1st
        ' 
        CheckBox1st.Location = New Point(470, 5)
        CheckBox1st.Name = "CheckBox1st"
        CheckBox1st.Size = New Size(13, 14)
        CheckBox1st.TabIndex = 15
        CheckBox1st.Text = "1st"
        CheckBox1st.UseVisualStyleBackColor = True
        ' 
        ' Label11
        ' 
        Label11.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(5, 2)
        Label11.Name = "Label11"
        Label11.Size = New Size(82, 20)
        Label11.TabIndex = 19
        Label11.Text = "Student Name:"
        Label11.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label12
        ' 
        Label12.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(5, 24)
        Label12.Name = "Label12"
        Label12.Size = New Size(82, 20)
        Label12.TabIndex = 20
        Label12.Text = "LRN: "
        Label12.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label13
        ' 
        Label13.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(491, 2)
        Label13.Name = "Label13"
        Label13.Size = New Size(35, 20)
        Label13.TabIndex = 21
        Label13.Text = "1st"
        Label13.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label14
        ' 
        Label14.Font = New Font("Segoe UI", 6.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label14.Location = New Point(491, 24)
        Label14.Name = "Label14"
        Label14.Size = New Size(35, 20)
        Label14.TabIndex = 22
        Label14.Text = "2nd"
        Label14.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' cmbstatus
        ' 
        cmbstatus.BackColor = Color.Silver
        cmbstatus.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        cmbstatus.FormattingEnabled = True
        cmbstatus.Items.AddRange(New Object() {"G-10 COMPLETER PUBLIC", "G-10 COMPLETER PRIVATE", "G-10 COMPLETER ALS COMPLETER", "G-10 COMPLETER BALIK-ARAL", "G-10 COMPLETER G-11 REPEATER", "G-10 COMPLETER CONTINUING", "", "", ""})
        cmbstatus.Location = New Point(58, 147)
        cmbstatus.Name = "cmbstatus"
        cmbstatus.Size = New Size(172, 23)
        cmbstatus.TabIndex = 13
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(0, 146)
        Label9.Name = "Label9"
        Label9.Size = New Size(61, 21)
        Label9.TabIndex = 12
        Label9.Text = "Status:"
        ' 
        ' cmbsection
        ' 
        cmbsection.BackColor = Color.Silver
        cmbsection.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        cmbsection.FormattingEnabled = True
        cmbsection.Items.AddRange(New Object() {"GRADE 11 - ICT1", "GRADE 11 - ICT2", "GRADE 12 - ICT 3", "GRADE 12 - ICT4", "GRADE 11 - ABM1", "GRADE 11 - ABM2", "GRADE 12 - ABM3", "GRADE 12 - ABM4", "GRADE 11 -  HE1", "GRADE 11 -  HE2", "GRADE 12 -  HE3", "GRADE 12 -  HE4", "GRADE 11 -  HUMMS1", "GRADE 11 -  HUMMS2", "GRADE 12 -  HUMMS3", "GRADE 12 -  HUMMS4", "", "", "", ""})
        cmbsection.Location = New Point(649, 122)
        cmbsection.Name = "cmbsection"
        cmbsection.Size = New Size(177, 23)
        cmbsection.TabIndex = 11
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(580, 123)
        Label8.Name = "Label8"
        Label8.Size = New Size(71, 21)
        Label8.TabIndex = 9
        Label8.Text = "Section:"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(244, 123)
        Label7.Name = "Label7"
        Label7.Size = New Size(55, 21)
        Label7.TabIndex = 8
        Label7.Text = "Track:"
        ' 
        ' txtregnum
        ' 
        txtregnum.BackColor = Color.Silver
        txtregnum.BorderStyle = BorderStyle.FixedSingle
        txtregnum.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txtregnum.Location = New Point(172, 122)
        txtregnum.Multiline = True
        txtregnum.Name = "txtregnum"
        txtregnum.Size = New Size(71, 24)
        txtregnum.TabIndex = 7
        txtregnum.Text = "SH-"
        txtregnum.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(0, 123)
        Label6.Name = "Label6"
        Label6.Size = New Size(175, 21)
        Label6.TabIndex = 6
        Label6.Text = "Registration Number:"
        ' 
        ' cmbtrack
        ' 
        cmbtrack.BackColor = Color.Silver
        cmbtrack.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        cmbtrack.FormattingEnabled = True
        cmbtrack.Items.AddRange(New Object() {"ACADEMIC TRACK", "TECHNICAL VOCATIONAL LIVELIHOOD"})
        cmbtrack.Location = New Point(300, 123)
        cmbtrack.Name = "cmbtrack"
        cmbtrack.Size = New Size(183, 23)
        cmbtrack.TabIndex = 5
        ' 
        ' Label5
        ' 
        Label5.BackColor = SystemColors.ControlDarkDark
        Label5.Font = New Font("Engravers MT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(0, 91)
        Label5.Name = "Label5"
        Label5.Size = New Size(826, 32)
        Label5.TabIndex = 4
        Label5.Text = "CERTIFICATE OF REGISTRATION"
        Label5.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label4
        ' 
        Label4.Font = New Font("Elephant", 6.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(105, 78)
        Label4.Name = "Label4"
        Label4.Size = New Size(614, 13)
        Label4.TabIndex = 3
        Label4.Text = "FB Page: PHILTECH-GMA"
        Label4.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label3
        ' 
        Label3.Font = New Font("Elephant", 6.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(105, 64)
        Label3.Name = "Label3"
        Label3.Size = New Size(614, 14)
        Label3.TabIndex = 2
        Label3.Text = "(046) 409-9490 / 0997-224-0222"
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label2
        ' 
        Label2.Font = New Font("Elephant", 6.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(105, 49)
        Label2.Name = "Label2"
        Label2.Size = New Size(614, 14)
        Label2.TabIndex = 1
        Label2.Text = "2nd FLOOR CDRM BLDG. GOVERNOR'S DRIVE BRGY G. MADERAN GMA, CAVITE"
        Label2.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label1
        ' 
        Label1.Font = New Font("Elephant", 14.9999981F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(105, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(614, 59)
        Label1.TabIndex = 0
        Label1.Text = "PHILIPPINE TECHNOLOGICAL INSTITUTE OF SCIENCE ARTS AND TRADE -- CENTRAL INC" & vbCrLf & vbCrLf
        Label1.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Button5
        ' 
        Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"), Image)
        Button5.BackgroundImageLayout = ImageLayout.Stretch
        Button5.Location = New Point(7, -1)
        Button5.Name = "Button5"
        Button5.Size = New Size(29, 25)
        Button5.TabIndex = 25
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.BackgroundImage = My.Resources.Resources.window_minimize
        Button2.BackgroundImageLayout = ImageLayout.Stretch
        Button2.Location = New Point(739, -1)
        Button2.Name = "Button2"
        Button2.Size = New Size(29, 25)
        Button2.TabIndex = 24
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.BackgroundImage = My.Resources.Resources.button
        Button3.BackgroundImageLayout = ImageLayout.Stretch
        Button3.Location = New Point(786, -1)
        Button3.Name = "Button3"
        Button3.Size = New Size(34, 25)
        Button3.TabIndex = 23
        Button3.UseVisualStyleBackColor = True
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackgroundImage = My.Resources.Resources.printer__1_
        PictureBox2.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox2.Location = New Point(338, 564)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(30, 29)
        PictureBox2.TabIndex = 26
        PictureBox2.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Georgia", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = Color.Black
        Button1.Location = New Point(329, 564)
        Button1.Name = "Button1"
        Button1.Size = New Size(155, 29)
        Button1.TabIndex = 27
        Button1.Text = "PRINT AND SAVE"
        Button1.TextAlign = ContentAlignment.MiddleRight
        Button1.UseVisualStyleBackColor = True
        ' 
        ' ENROLLMENT_STUDENT
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(828, 592)
        Controls.Add(PictureBox2)
        Controls.Add(Button5)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(Button3)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "ENROLLMENT_STUDENT"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ENROLLMENT_STUDENT"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        TableLayoutPanel3.ResumeLayout(False)
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel1.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtregnum As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents cmbtrack As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents cmbsection As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents CheckBox1st As CheckBox
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents cmbstatus As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents CheckBox2nd As CheckBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents CheckBoxhumms As CheckBox
    Friend WithEvents CheckBoxabm As CheckBox
    Friend WithEvents CheckBoxict As CheckBox
    Friend WithEvents CheckBoxhe As CheckBox
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents txtlrn As TextBox
    Friend WithEvents txtname As TextBox
    Friend WithEvents Button5 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label29 As Label
    Friend WithEvents RadioButtonafternoon As RadioButton
    Friend WithEvents RadioButtonmorning As RadioButton
End Class
